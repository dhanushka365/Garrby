X0 = 10;            %Assign values for coordinates
Y0 = 17;
Z0 = 7;

a1 = 10;             %Lengths of beams
a2 = 10.5;
a3 = 7;

ak = 8;             %Length and angle of preset 
Tk = deg2rad(20);


r1 = (power((power(X0,2)+power(Y0,2)),(1./2))-ak*cos(Tk));  %Calculate triangle distances
r2 = a1+ak*sin(Tk)-Z0;
r3 = power((power(r1,2)+power(r2,2)),(1./2));

e1 =(power(a3,2)-power(a2,2)-power(r3,2))/(-2*a2*r3);
e2 =(power(r3,2)-power(a2,2)-power(a3,2))/(-2*a2*a3);

fprintf('R values are');
disp(r1);
disp(r2);
disp(r3);
fprintf('E values are');
disp(e1);
disp(e2);

G1 = acos(e1);  %Calculate triangle angles
G2 = atan(r2/r1);
G3 = acos(e2);
                                                                           
T0 = rad2deg(atan(Y0/X0));    %Calculate required angles to move
T1 = rad2deg(G2)-rad2deg(G1); 
T2 = 180 - rad2deg(G3);

fprintf('Angles are');
disp(T0);disp(T1);disp(T2);




