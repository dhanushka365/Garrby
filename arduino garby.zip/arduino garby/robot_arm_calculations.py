import numpy as np

X0 = 2;              #Assign values for coordinates
Y0 = 4;
Z0 = 4;

a1 = 6.5;             #Lengths of beams
a2 = 6.5;
a3 = 6.5;

ak = 4;             #Length and angle of preset 
Tk = np.deg2rad(90);

r1 = (pow((np.power(X0,2)+pow(Y0,2)),(1./2))-ak*np.cos(Tk));  #Calculate triangle distances
r2 = a1+ak*np.sin(Tk)-Z0;
r3 = pow((pow(r1,2)+pow(r2,2)),(1./2));

e1 =(pow(a3,2)-pow(a2,2)-pow(r3,2))/(-2*a2*r3);
e2 =(pow(r3,2)-pow(a2,2)-pow(a3,2))/(-2*a2*a3);

print('R values are');
print(r1);
print(r2);
print(r3);
print('E values are');
print(e1);
print(e2);

G1 = np.arccos(e1);  #Calculate triangle angles
G2 = np.arctan(r2/r1);
G3 = np.arccos(e2);

print('G values are');
print(G1);
print(G2);
print(G3);
                                                                        
T0 = np.rad2deg(np.arctan(Y0/X0));    #Calculate required angles to move
T1 = np.rad2deg(G2)-np.rad2deg(G1); 
T2 = 180 - np.rad2deg(G3);

print('Angles are');
print(T0);print(T1);print(T2);




